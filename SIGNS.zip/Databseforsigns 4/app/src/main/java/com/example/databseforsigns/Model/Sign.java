package com.example.databseforsigns.Model;

public class Sign {
    private String signName;
    private int diffLevel;
    private String meaning;
    private String imageUrl;

    public Sign() {}

    public Sign(String signName, String meaning, String imageUrl, int diffLevel){
        this.signName = signName;
        this.meaning = meaning;
        this.imageUrl = imageUrl;
        this.diffLevel = diffLevel;
    }

    public String getSignName(){
        return signName;
    }
    public String getMeaning(){
        return meaning;
    }


    public String getImageUrl(){
        return imageUrl;
    }
    public int getDiffLevel(){
        return diffLevel;
    }




}
