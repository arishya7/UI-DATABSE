package com.example.databseforsigns.Model;

public class Users {
    private String firstname;
    private String lastname;
    private String username;
    private String password;
    private String rank;
    private String profilePicture; // New field for profile picture
    private int experiencePoints;  // New field for experience points
    private String language; // New field for language
    private String lessonFrequency; // New field for lesson frequency
    private String milestone; // New field for milestone
    private String signLanguage; // New field for sign language
    private String level; // New field for proficiency level

    public Users() {
        this.experiencePoints = 0;
        this.language = "English"; // Default value
        this.level = "Beginner"; // Default level
    }

    public Users(String firstname, String lastname, String username,
                 String password, String rank, String profilePicture,
                 int experiencePoints, String language, String lessonFrequency,
                 String milestone, String signLanguage, String level) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.username = username;
        this.password = password;
        this.rank = rank;
        this.profilePicture = profilePicture;
        this.experiencePoints = experiencePoints;
        this.language = language;
        this.lessonFrequency = lessonFrequency;
        this.milestone = milestone;
        this.signLanguage = signLanguage;
        this.level = level;

    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    public int getExperiencePoints() {
        return experiencePoints;
    }

    public void setExperiencePoints(int experiencePoints) {
        this.experiencePoints = experiencePoints;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getLessonFrequency() {
        return lessonFrequency;
    }

    public void setLessonFrequency(String lessonFrequency) {
        this.lessonFrequency = lessonFrequency;
    }

    public String getMilestone() {
        return milestone;
    }

    public void setMilestone(String milestone) {
        this.milestone = milestone;
    }

    public String getSignLanguage() {
        return signLanguage;
    }

    public void setSignLanguage(String signLanguage) {
        this.signLanguage = signLanguage;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }
}

