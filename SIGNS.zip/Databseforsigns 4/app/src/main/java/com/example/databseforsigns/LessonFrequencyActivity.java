package com.example.databseforsigns;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.databseforsigns.Model.Users;
import com.google.firebase.firestore.FirebaseFirestore;

public class LessonFrequencyActivity extends AppCompatActivity {

    private ImageButton btnBack;
    private RelativeLayout layoutOnceMonth, layoutTwiceMonth, layoutOnceWeek,
            layoutTwiceWeek, layoutEveryOtherDay, layoutEveryday;
    private Button btnContinue;
    private String selectedFrequency = "";
    private FirebaseFirestore db;
    private Users currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson_frequency);

        // Initialize FirebaseFirestore
        db = FirebaseFirestore.getInstance();
        currentUser = new Users();

        // Get language from previous activity if available
        if (getIntent().hasExtra("language")) {
            currentUser.setLanguage(getIntent().getStringExtra("language"));
        }

        // Initialize views
        btnBack = findViewById(R.id.btnBack);
        layoutOnceMonth = findViewById(R.id.layoutOnceMonth);
        layoutTwiceMonth = findViewById(R.id.layoutTwiceMonth);
        layoutOnceWeek = findViewById(R.id.layoutOnceWeek);
        layoutTwiceWeek = findViewById(R.id.layoutTwiceWeek);
        layoutEveryOtherDay = findViewById(R.id.layoutEveryOtherDay);
        layoutEveryday = findViewById(R.id.layoutEveryday);
        btnContinue = findViewById(R.id.btnContinue);

        // Set click listeners for frequency options
        layoutOnceMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelectedOption(layoutOnceMonth);
                selectedFrequency = "Once a month (Casual)";
            }
        });

        layoutTwiceMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelectedOption(layoutTwiceMonth);
                selectedFrequency = "Twice a month (Occasional)";
            }
        });

        layoutOnceWeek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelectedOption(layoutOnceWeek);
                selectedFrequency = "Once a week (Steady)";
            }
        });

        layoutTwiceWeek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelectedOption(layoutTwiceWeek);
                selectedFrequency = "Twice a week (Engaging)";
            }
        });

        layoutEveryOtherDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelectedOption(layoutEveryOtherDay);
                selectedFrequency = "Every other day (Intensive)";
            }
        });

        layoutEveryday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelectedOption(layoutEveryday);
                selectedFrequency = "Everyday (Proactive)";
            }
        });

        // Back button click listener
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        // Continue button click listener
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!selectedFrequency.isEmpty()) {
                    currentUser.setLessonFrequency(selectedFrequency);

                    // Navigate to the milestone selection screen instead of MainActivity
                    Intent intent = new Intent(LessonFrequencyActivity.this, MilestoneSelectionActivity.class);
                    intent.putExtra("language", currentUser.getLanguage());
                    intent.putExtra("lessonFrequency", selectedFrequency);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LessonFrequencyActivity.this,
                            "Please select a frequency", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    // Helper method to highlight the selected option
    private void setSelectedOption(RelativeLayout selectedLayout) {
        // Reset all layouts
        layoutOnceMonth.setBackgroundResource(R.drawable.option_button_background);
        layoutTwiceMonth.setBackgroundResource(R.drawable.option_button_background);
        layoutOnceWeek.setBackgroundResource(R.drawable.option_button_background);
        layoutTwiceWeek.setBackgroundResource(R.drawable.option_button_background);
        layoutEveryOtherDay.setBackgroundResource(R.drawable.option_button_background);
        layoutEveryday.setBackgroundResource(R.drawable.option_button_background);

        // Highlight the selected layout
        selectedLayout.setBackgroundColor(getResources().getColor(R.color.purple_200));
    }
}
