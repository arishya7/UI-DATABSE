package com.example.databseforsigns;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.example.databseforsigns.Model.Users;

public class LanguageSelectionActivity extends AppCompatActivity {

    private RadioGroup languageGroup;
    private Button continueButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_selection);

        languageGroup = findViewById(R.id.languageGroup);
        continueButton = findViewById(R.id.btnContinue);

        // Set default language value
        Users user = new Users();
        user.setLanguage("English");

        // Handle language selection
        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = languageGroup.getCheckedRadioButtonId();
                String selectedLanguage = "English";

                if (selectedId == R.id.radioEnglishUS) {
                    selectedLanguage = "English (US)";
                } else if (selectedId == R.id.radioEnglishUK) {
                    selectedLanguage = "English (UK)";
                } else if (selectedId == R.id.radioChinese) {
                    selectedLanguage = "中文 (CN)";
                } else if (selectedId == R.id.radioKorean) {
                    selectedLanguage = "한국어 (KR)";
                } else if (selectedId == R.id.radioJapanese) {
                    selectedLanguage = "日本語 (JP)";
                } else if (selectedId == R.id.radioSpanish) {
                    selectedLanguage = "Español (ES)";
                } else if (selectedId == R.id.radioIndonesian) {
                    selectedLanguage = "Bahasa Indo (ID)";
                } else if (selectedId == R.id.radioTagalog) {
                    selectedLanguage = "Tagalog (PH)";
                }

                // Create intent for LessonFrequencyActivity with selected language
                Intent intent = new Intent(LanguageSelectionActivity.this, LessonFrequencyActivity.class);
                intent.putExtra("language", selectedLanguage);
                startActivity(intent);
                finish();
            }
        });

    }
}
