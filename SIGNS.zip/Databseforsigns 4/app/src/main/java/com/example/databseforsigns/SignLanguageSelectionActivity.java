package com.example.databseforsigns;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.databseforsigns.Model.Users;

public class SignLanguageSelectionActivity extends AppCompatActivity {

    private ImageButton btnBack;
    private LinearLayout layoutASL, layoutBSL, layoutOGS;
    private Button btnContinue;
    private String selectedSignLanguage = "";
    private Users currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_language_selection);

        // Initialize views
        btnBack = findViewById(R.id.btnBack);
        layoutASL = findViewById(R.id.layoutASL);
        layoutBSL = findViewById(R.id.layoutBSL);
        layoutOGS = findViewById(R.id.layoutOGS);
        btnContinue = findViewById(R.id.btnContinue);

        // Initialize user object
        currentUser = new Users();

        // Get data from previous activities if available
        if (getIntent().hasExtra("language")) {
            currentUser.setLanguage(getIntent().getStringExtra("language"));
        }

        if (getIntent().hasExtra("lessonFrequency")) {
            currentUser.setLessonFrequency(getIntent().getStringExtra("lessonFrequency"));
        }

        if (getIntent().hasExtra("milestone")) {
            currentUser.setMilestone(getIntent().getStringExtra("milestone"));
        }

        // Set click listeners for sign language options
        layoutASL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedSignLanguage = "ASL";
                highlightSelectedOption(layoutASL);
            }
        });

        layoutBSL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedSignLanguage = "BSL";
                highlightSelectedOption(layoutBSL);
            }
        });

        layoutOGS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedSignLanguage = "ÖGS";
                highlightSelectedOption(layoutOGS);
            }
        });

        // Back button click listener
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        // Continue button click listener
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!selectedSignLanguage.isEmpty()) {
                    // Save the user's sign language preference
                    currentUser.setSignLanguage(selectedSignLanguage);

                    // Navigate to level selection screen instead of MainActivity
                    Intent intent = new Intent(SignLanguageSelectionActivity.this, LevelSelectionActivity.class);
                    intent.putExtra("language", currentUser.getLanguage());
                    intent.putExtra("lessonFrequency", currentUser.getLessonFrequency());
                    intent.putExtra("milestone", currentUser.getMilestone());
                    intent.putExtra("signLanguage", selectedSignLanguage);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(SignLanguageSelectionActivity.this,
                            "Please select a sign language", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Helper method to highlight the selected option
    private void highlightSelectedOption(LinearLayout selectedLayout) {
        // Reset all layouts
        layoutASL.setBackgroundResource(R.drawable.option_button_background);
        layoutBSL.setBackgroundResource(R.drawable.option_button_background);
        layoutOGS.setBackgroundResource(R.drawable.option_button_background);

        // Highlight selected option
        selectedLayout.setBackgroundColor(getResources().getColor(R.color.purple_200));
    }
}
