package com.example.databseforsigns;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class UsersActivity extends AppCompatActivity {

    private EditText etFirstName, etLastName, etUsername, etPassword, etConfirmPassword;
    private Button btnSignUp, btnSignIn;
    private TextView tvStatus;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        db = FirebaseFirestore.getInstance();

        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnSignUp = findViewById(R.id.btnSignUp);
        btnSignIn = findViewById(R.id.btnSignIn);
        tvStatus = findViewById(R.id.tvStatus);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signUpUser();
            }
        });


        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signInUser();
            }
        });
    }

    private void signUpUser() {
        String firstName = etFirstName.getText().toString().trim();
        String lastName = etLastName.getText().toString().trim();
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("Passwords do not match");
            return;
        }

        db.collection("users")
                .whereEqualTo("username", username)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            if (task.getResult().isEmpty()) {
                                createNewUser(firstName, lastName, username, password);
                            } else {
                                etUsername.setError("Username already exists");
                            }
                        } else {
                            Log.e("SignUp", "Error checking username", task.getException());
                            tvStatus.setText("Error checking username availability");
                        }
                    }
                });
    }

    private void createNewUser(String firstName, String lastName, String username, String password) {
        Map<String, Object> user = new HashMap<>();
        user.put("firstname", firstName);
        user.put("lastname", lastName);
        user.put("username", username);
        user.put("password", password);
        user.put("rank", "Bronze");
        user.put("points", 0);
        user.put("counter", 0);
        user.put("language", "English");


        db.collection("users")
                .add(user)
                .addOnCompleteListener(new OnCompleteListener<com.google.firebase.firestore.DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<com.google.firebase.firestore.DocumentReference> task) {
                        if (task.isSuccessful()) {
                            tvStatus.setText("Sign up successful!");
                            Intent intent = new Intent(UsersActivity.this, LanguageSelectionActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            tvStatus.setText("Sign up failed: " + task.getException().getMessage());
                        }
                    }
                });
    }

    private void signInUser() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username)) {
            etUsername.setError("Username is required");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password is required");
            return;
        }

        db.collection("users")
                .whereEqualTo("username", username)
                .whereEqualTo("password", password)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            if (!task.getResult().isEmpty()) {
                                // User found, login successful
                                DocumentSnapshot document = task.getResult().getDocuments().get(0);
                                tvStatus.setText("Sign in successful!");

                                // Get user data
                                long points = document.getLong("points");
                                long counter = document.getLong("counter");

                                //lessons unlocked based on these points
                                if (points >= 26 && counter == 0) {
                                    db.collection("users").document(document.getId())
                                            .update("counter", 1)
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        tvStatus.setText("Sign in successful!");
                                                    }
                                                }
                                            });
                                }


                            } else {
                                tvStatus.setText("Invalid username or password");
                            }
                        } else {
                            tvStatus.setText("Error signing in: " + task.getException().getMessage());
                        }
                    }
                });
    }

    private void clearForm() {
        etFirstName.setText("");
        etLastName.setText("");
        etUsername.setText("");
        etPassword.setText("");
        etConfirmPassword.setText("");
    }

    public void updateUserPoints(String userId, int pointsToAdd) {
        db.collection("users").document(userId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                long currentPoints = document.getLong("points");
                                long newPoints = currentPoints + pointsToAdd;
                                long counter = document.getLong("counter");


                                db.collection("users").document(userId)
                                        .update("points", newPoints)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    Log.d("UpdatePoints", "Points updated successfully");


                                                    if (newPoints >= 26 && counter == 0) {
                                                        db.collection("users").document(userId)
                                                                .update("counter", 1)
                                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                    @Override
                                                                    public void onComplete(@NonNull Task<Void> task) {
                                                                        if (task.isSuccessful()) {
                                                                            Log.d("UpdateCounter", "Counter updated to 1");
                                                                        }
                                                                    }
                                                                });
                                                    }
                                                }
                                            }
                                        });
                            }
                        }
                    }
                });
    }
}