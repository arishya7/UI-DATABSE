package com.example.databseforsigns;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.databseforsigns.Model.Users;

public class LevelSelectionActivity extends AppCompatActivity {

    private ImageButton btnBack;
    private LinearLayout layoutBeginnerLevel, layoutIntermediateLevel, layoutAdvancedLevel;
    private Button btnFinish;
    private String selectedLevel = "Beginner"; // Default level
    private Users currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_selection);

        // Initialize views
        btnBack = findViewById(R.id.btnBack);
        layoutBeginnerLevel = findViewById(R.id.layoutBeginnerLevel);
        layoutIntermediateLevel = findViewById(R.id.layoutIntermediateLevel);
        layoutAdvancedLevel = findViewById(R.id.layoutAdvancedLevel);
        btnFinish = findViewById(R.id.btnFinish);

        // Initialize user object
        currentUser = new Users();

        // Get data from previous activities if available
        if (getIntent().hasExtra("language")) {
            currentUser.setLanguage(getIntent().getStringExtra("language"));
        }

        if (getIntent().hasExtra("lessonFrequency")) {
            currentUser.setLessonFrequency(getIntent().getStringExtra("lessonFrequency"));
        }

        if (getIntent().hasExtra("milestone")) {
            currentUser.setMilestone(getIntent().getStringExtra("milestone"));
        }

        if (getIntent().hasExtra("signLanguage")) {
            currentUser.setSignLanguage(getIntent().getStringExtra("signLanguage"));
        }

        // Pre-select Beginner level as default
        highlightSelectedOption(layoutBeginnerLevel);

        // Set click listeners for level options
        layoutBeginnerLevel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedLevel = "Beginner";
                highlightSelectedOption(layoutBeginnerLevel);
            }
        });

        layoutIntermediateLevel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedLevel = "Intermediate";
                highlightSelectedOption(layoutIntermediateLevel);
            }
        });

        layoutAdvancedLevel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedLevel = "Advanced";
                highlightSelectedOption(layoutAdvancedLevel);
            }
        });

        // Back button click listener
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        // Finish button click listener
        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save the user's level preference
                currentUser.setLevel(selectedLevel);

                // Navigate to MainActivity
                Intent intent = new Intent(LevelSelectionActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    // Helper method to highlight the selected option
    private void highlightSelectedOption(LinearLayout selectedLayout) {
        // Reset all layouts
        layoutBeginnerLevel.setBackgroundResource(R.drawable.option_button_background);
        layoutIntermediateLevel.setBackgroundResource(R.drawable.option_button_background);
        layoutAdvancedLevel.setBackgroundResource(R.drawable.option_button_background);

        // Highlight selected option
        selectedLayout.setBackgroundColor(getResources().getColor(R.color.purple_200));
    }
}
