package com.example.databseforsigns;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Practice extends AppCompatActivity {

    private TextView instructionText;
    private Button doneButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.practice);

        instructionText = findViewById(R.id.textletter);
        doneButton = findViewById(R.id.buttondone);

        String letter = getIntent().getStringExtra("letter");

        instructionText.setText("Practice the sign for: " + letter);

        doneButton.setOnClickListener(v -> {

            finish();
        });
    }
}
