package com.example.databseforsigns.Model;

public class Lesson {
    private String title;
    private String description;
    private int difficulty;
    private String timeCreated;
    private String mediaUrl;

    public Lesson() {}

    public Lesson(String title, String description, int difficulty, String timeCreated, String mediaUrl) {
        this.title = title;
        this.description = description;
        this.difficulty = difficulty;
        this.timeCreated = timeCreated;
        this.mediaUrl = mediaUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public String getTimeCreated() {
        return timeCreated;
    }

    public void setTimeCreated(String timeCreated) {
        this.timeCreated = timeCreated;
    }

    public String getMediaUrl() {
        return mediaUrl;
    }

    public void setMediaUrl(String mediaUrl) {
        this.mediaUrl = mediaUrl;
    }
}
