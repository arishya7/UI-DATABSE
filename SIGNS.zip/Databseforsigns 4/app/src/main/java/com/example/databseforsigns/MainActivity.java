package com.example.databseforsigns;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.firestore.FirebaseFirestore;

import com.example.databseforsigns.Model.Sign;
import com.example.databseforsigns.Model.Lesson;
import com.example.databseforsigns.Model.Users;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        db = FirebaseFirestore.getInstance();

        Button selectImageButton = findViewById(R.id.button);
        if (selectImageButton != null) {
            selectImageButton.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            });
        } else {
            Log.e("MainActivity", "Button with ID 'button' not found in layout!");
        }

        // Add signs
        List<Sign> signList = new ArrayList<>();
        signList.add(new Sign("A", "1st letter", "https://rb.gy/2kxp1d", 1));
        signList.add(new Sign("B", "2nd letter", "https://rb.gy/nzxk7i", 1));
        signList.add(new Sign("C", "3rd letter", "https://rb.gy/5yt30g", 1));
        signList.add(new Sign("D", "4th letter", "https://rb.gy/5ahtw1", 1));
        signList.add(new Sign("E", "5th letter", "https://rb.gy/hy05ep", 1));
        signList.add(new Sign("F", "6th letter", "https://rebrand.ly/zam7d0a", 1));
        signList.add(new Sign("G", "7th letter", "https://rebrand.ly/753d12", 1));
        signList.add(new Sign("H", "8th letter", "https://rb.gy/rxshpj", 1));
        signList.add(new Sign("I", "9th letter", "https://rb.gy/b8ccgz", 1));
        signList.add(new Sign("J", "10th letter", "https://rb.gy/p9fvx5", 1));
        signList.add(new Sign("K", "11th letter", "https://rb.gy/b2kx1g", 1));
        signList.add(new Sign("L", "12th letter", "https://rb.gy/3i2g12", 1));
        signList.add(new Sign("M", "13th letter", "https://rb.gy/xxp2ai", 1));
        signList.add(new Sign("N", "14th letter", "https://rb.gy/wbpp2k", 1));
        signList.add(new Sign("O", "15th letter", "https://rb.gy/nmxzil", 1));
        signList.add(new Sign("P", "16th letter", "https://rb.gy/qhhhcn", 1));
        signList.add(new Sign("Q", "17th letter", "https://rb.gy/30zlsy", 1));
        signList.add(new Sign("R", "18th letter", "https://rb.gy/iwpe4x", 1));
        signList.add(new Sign("S", "19th letter", "https://rb.gy/4v5lz2", 1));
        signList.add(new Sign("T", "20th letter", "https://rb.gy/xvjpo8", 1));
        signList.add(new Sign("U", "21st letter", "https://rb.gy/qdbe9e", 1));
        signList.add(new Sign("V", "22nd letter", "https://rb.gy/6oiwxh", 1));
        signList.add(new Sign("W", "23rd letter", "https://rb.gy/2atpxv", 1));
        signList.add(new Sign("X", "24th letter", "https://rb.gy/fj3ndh", 1));
        signList.add(new Sign("Y", "25th letter", "https://rb.gy/g592k0", 1));
        signList.add(new Sign("Z", "26th letter", "https://rb.gy/trt9oa", 1));



        for (Sign sign : signList) {
            addSign(sign);
        }

        // Add lessons
        List<Lesson> lessonList = new ArrayList<>();
        lessonList.add(new Lesson("Lesson 1", "Introduction to letters", 1, "2025-03-27", "https://example.com/media1"));
        lessonList.add(new Lesson("Lesson 2", "Advanced letter combinations", 2, "2025-03-26", "https://example.com/media2"));

        for (Lesson lesson : lessonList) {
            addLesson(lesson);
        }

        // Add users
        List<Users> userList = new ArrayList<>();
        userList.add(new Users(
                "Brian", "Lim", "BrianLim123",
                "Password123", "Bronze",
                "https://example.com/profile/brian.jpg",
                100, "English", "Once a week",
                "3-day streak", "ASL", "Beginner"
        ));

        for (Users user : userList) {
            addUser(user);
        }

        for (Users user : userList) {
            addUser(user);
        }

        View rootView = findViewById(R.id.main);
        if (rootView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
    }

    public void addSign(Sign sign) {
        Map<String, Object> signMap = new HashMap<>();
        signMap.put("name", sign.getSignName());
        signMap.put("meaning", sign.getMeaning());
        signMap.put("image", sign.getImageUrl());
        signMap.put("level", sign.getDiffLevel());

        db.collection("signs").add(signMap)
                .addOnSuccessListener(documentReference -> {
                    Log.d("FireStore", "Sign added " + documentReference.getId());
                });
    }

    public void addLesson(Lesson lesson) {
        Log.d("FireStore", "Attempting to add lesson: " + lesson.getTitle());

        Map<String, Object> lessonMap = new HashMap<>();
        lessonMap.put("title", lesson.getTitle());
        lessonMap.put("description", lesson.getDescription());
        lessonMap.put("difficulty", lesson.getDifficulty());
        lessonMap.put("timeCreated", lesson.getTimeCreated());
        lessonMap.put("media", lesson.getMediaUrl());

        db.collection("lessons")
                .add(lessonMap)
                .addOnSuccessListener(documentReference -> {
                    Log.d("FireStore", "Lesson added with ID: " + documentReference.getId());
                })
                .addOnFailureListener(e -> {
                    Log.e("FireStore", "Error adding lesson", e);
                });
    }

    public void addUser(Users user) {
        Map<String, Object> userMap = new HashMap<>();
        userMap.put("firstname", user.getFirstname());
        userMap.put("lastname", user.getLastname());
        userMap.put("username", user.getUsername());
        userMap.put("password", user.getPassword());
        userMap.put("rank", user.getRank());

        db.collection("users")
                .add(userMap)
                .addOnSuccessListener(documentReference -> {
                    Log.d("FireStore", "User added " + documentReference.getId());
                });
    }
}
