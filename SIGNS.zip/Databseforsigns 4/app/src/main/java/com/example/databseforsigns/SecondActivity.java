package com.example.databseforsigns;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class SecondActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private ImageView imageView;
    private TextView letterLabel;
    private Button practiceButton;
    private boolean hasStarted = false;
    private int currentLetterIndex = 0;
    private final char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        db = FirebaseFirestore.getInstance();
        imageView = findViewById(R.id.imageView);
        letterLabel = findViewById(R.id.textView);
        practiceButton = findViewById(R.id.pracButton);

        loadSignImage(alphabet[currentLetterIndex]);

        practiceButton.setOnClickListener(v -> {
            char currentLetter = alphabet[currentLetterIndex];
            System.out.println(currentLetterIndex);

            Intent intent = new Intent(SecondActivity.this, Practice.class);
            intent.putExtra("letter", String.valueOf(currentLetter));
            intent.putExtra("index", currentLetterIndex); // so we can go to next letter after
            startActivity(intent);
        });
    }

    // When this activity resumes, go to next letter
    @Override
    protected void onResume() {
        super.onResume();

        // Increment index only if user has practiced the previous letter
        if (hasStarted) {
            if (currentLetterIndex < alphabet.length - 1) {
                currentLetterIndex++;
                loadSignImage(alphabet[currentLetterIndex]);
            } else {
                letterLabel.setText("All done!");
                imageView.setImageResource(0);
                practiceButton.setEnabled(false);
            }
        }
        else{
            hasStarted = true;
        }
    }
    private void loadSignImage(char letter) {
        String letterStr = String.valueOf(letter);
        letterLabel.setText("Letter: " + letterStr);

        db.collection("signs")
                .whereEqualTo("name", letterStr)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        DocumentSnapshot document = queryDocumentSnapshots.getDocuments().get(0);
                        String imageUrl = document.getString("image");

                        // Ensure the image URL is valid before loading
                        if (imageUrl != null && !imageUrl.isEmpty()) {
                            Glide.with(this).load(imageUrl).into(imageView);
                        } else {
                            Log.w("SecondActivity", "No image URL found for " + letterStr);

                        }
                    } else {
                        Log.w("SecondActivity", "No sign found for " + letterStr);

                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("Firestore", "Error fetching image", e);

                });
    }

}
